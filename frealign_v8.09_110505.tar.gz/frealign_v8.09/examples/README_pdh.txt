Acknowledgements:

The data used in the sample scripts was genereously provided by
Milne, Shi, Rosenthal, Sunshine, Domingo, Wu, Brooks, Perham, Henderson 
and Subramaniam.

Reference:

Milne, et al.(2002) EMBO J. 21:5587-98. Molecular architecture and
functional mechanism of an icosahedral pyruvate dehydrogenase
multienzyme complex.
