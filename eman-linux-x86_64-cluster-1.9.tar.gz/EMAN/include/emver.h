#ifdef FILESERVER
	#define EMVER "1.9 Cluster ($Date: 2009/02/18 05:12:22 $)"
#else
	#define EMVER "1.9 ($Date: 2009/02/18 05:12:22 $)"
#endif

