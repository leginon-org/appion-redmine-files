#include <qfont.h>
#include <qfontmetrics.h>

void EMQInit(QApplication *app);

int doQprog(int num,int denom,const char *msg);
