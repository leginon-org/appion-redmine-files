import chimera
#from chimera.baseDialog import ModelessDialog
import os
import time
