#ifndef __pyqem_h__
#define __pyqem_h__


#ifdef GUI
void export_qt();
void export_ImShape();
void export_BPoint();
void export_Image();
void export_ImageMx();
#endif

#endif
