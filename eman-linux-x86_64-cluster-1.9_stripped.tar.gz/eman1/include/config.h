// used by autoconfig/automake system
