#include "ifftw.h"



extern const solvtab X(solvtab_dft_simd);
const solvtab X(solvtab_dft_simd) = {
   SOLVTAB_END
};
