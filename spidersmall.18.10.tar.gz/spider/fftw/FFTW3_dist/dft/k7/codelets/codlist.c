#include "ifftw.h"



extern const solvtab X(solvtab_dft_k7);
const solvtab X(solvtab_dft_k7) = {
   SOLVTAB_END
};
