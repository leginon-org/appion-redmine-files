/*--------------------------------------------------------------------------*/
extern int  MessageDisplay
    (
        const char
        *Message
    );

