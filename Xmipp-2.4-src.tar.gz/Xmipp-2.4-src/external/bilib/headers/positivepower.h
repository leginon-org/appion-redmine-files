/*--------------------------------------------------------------------------*/
#define   POSITIVE_POWER_TRADE_OFF 256

/*--------------------------------------------------------------------------*/
extern double PositiveIntPower
    (
        double Argument,   /* argument */
        long Exponent   /* exponent */
    );

